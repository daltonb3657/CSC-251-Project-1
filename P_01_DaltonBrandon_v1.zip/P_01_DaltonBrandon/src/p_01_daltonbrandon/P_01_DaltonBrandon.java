
/* Brandon Dalton
 * 8/28/2019
 * This program creates a temperature table Celsius to Fahrenheit
 * (Copy of CelsiusFahrenheitFahrenheitCelsius)
*/
package p_01_daltonbrandon;
import java.text.DecimalFormat;
public class P_01_DaltonBrandon
{
   public static void main(String[] args)
   {
      double fahrenheit;   // The Fahrenheit temperature
      double celsius;      // The Celsius temperature
      
      // Create a DecimalFormat class to format output.
      DecimalFormat fmt = new DecimalFormat(" 0.0");
             
      // Display the table headings.
      System.out.println("Celsius\t\tFahrenheit");
      System.out.println("------------------------------");
      
      // Display the table.
      for (celsius = 0; celsius <= 100; celsius++)
      {
         fahrenheit = (9.0 / 5.0) * celsius + 32;
         System.out.println(fmt.format(celsius) +
                            "\t\t" + 
                            fmt.format(fahrenheit));
      }
   }
}
